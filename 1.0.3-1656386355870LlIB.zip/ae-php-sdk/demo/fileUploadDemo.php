<?php
    include "../IopSdk.php";

//    $c = new IopClient('https://api.taobao.tw/rest', '${appKey}', '${appSecret}');
//    $request = new IopRequest('/xiaoxuan/mockfileupload');
//    $request->addApiParam('file_name','pom.xml');
//    $request->addFileParam('file_bytes',file_get_contents('/Users/xt/Documents/work/tasp/tasp/pom.xml'));
//
//    var_dump($c->execute($request));
?>