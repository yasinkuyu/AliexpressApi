<?php
class UrlConstants
{
	static $api_gateway_url_tw = "https://api-sg.aliexpress.com/sync";
//	static $api_authorization_url = "https://auth.taobao.tw/rest";
}
